<?php
/**
 * 2020 Maxpay
 * @copyright 2020 Maxpay
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

$_['heading_title']  = 'Maxpay payment Gateway';

$_['text_title']     = 'Maxpay payment methods';
$_['text_chosen']    = 'Selected payment method: Maxpay';
// Heading
$_['heading_title_failed'] = 'Failed Payment!';

// Text
$_['text_basket']   = 'Shopping Cart';
$_['text_checkout'] = 'Checkout';
$_['text_failure']  = 'Failed Payment';

$_['button_confirm'] = 'Confirm order';
$_['button_back_to_cart'] = 'Back to cart';
$_['button_confirm'] = 'Confirm order';

$_['decline_text_message']  = '<p>There was a problem processing your payment and the order did not complete.</p>

<p>The reason is:</p>
<ul>
  <li>3D secure failed</li>
</ul>

<p>Please try to order again using another credit card or contact with your bank.</p>
';