<?php
/**
 * 2020 Maxpay
 * @copyright 2020 Maxpay
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

$_['heading_title'] = 'Maxpay payment Gateway';

$_['tab_account'] = 'Main Configuration';
$_['tab_payment'] = 'Extra Configuration';
$_['tab_order_status'] = 'Order Status';
$_['tab_additions'] = 'Project additions';

$_['text_extension'] = 'Extensions';
$_['text_payment'] = 'Payment';
$_['text_success'] = 'Success: You have modified Maxpay account details!';
$_['text_select'] = 'Select from the list...';
$_['text_enabled'] = 'On';
$_['text_disabled'] = 'Off';
$_['text_yes'] = 'On';
$_['text_no'] = 'Off';
$_['text_on'] = 'On';
$_['text_off'] = 'Off';
$_['text_edit'] = 'Edit Maxpay';
$_['text_maxpay'] = '<img src="view/image/payment/maxpay.png" alt="Maxpay" title="Maxpay" style="height:27px;" />';

$_['label_status'] = 'Status:';
$_['label_public_key'] = 'Public Key:';
$_['label_privat_key'] = 'Privat Key:';
$_['label_public_test_key'] = 'Public Test Key:';
$_['label_privat_test_key'] = 'Privat Test Key:';
$_['label_test'] = 'Test:';
$_['label_sort_order'] = 'Sort Order:';
$_['label_total'] = 'Total:';
$_['label_title'] = 'Title:';
$_['label_description'] = 'Description:';
$_['label_paymentlist'] = 'Display payment list:';
$_['label_multi_select'] = 'Specific Countries:';
$_['label_grid_view'] = 'Gridview Display:';
$_['label_geo_zone'] = 'Geo Zone:';
$_['label_new_order_status'] = 'New order Status:';
$_['label_canceled_status'] = 'Failed order Status:';
$_['label_refunded_status'] = 'Redund order Status:';
$_['label_order_status'] = 'Paid order status:';

$_['entry_public_key'] = 'Public key';
$_['entry_privat_key'] = 'Privat Key';
$_['entry_public_test_key'] = 'Public test key';
$_['entry_privat_test_key'] = 'Privat test Key';
$_['entry_total'] = 'Min. order amount';
$_['entry_title'] = 'Maxpay payment';
$_['entry_multi_select'] = 'Specific countries';
$_['entry_description'] = 'Pay using Maxpay system';
$_['entry_sort_order'] = 'Payment gateway ordering id';
$_['entry_owner_code'] = 'Ownership code';

$_['help_callback'] = '';
$_['help_total'] = 'The checkout total the order must reach before this payment method becomes active.';
$_['help_multi_select'] = 'Select which country payments to display (empty means all).';

$_['error_permission'] = 'Warning: You do not have permission to modify payment Maxpay!';
$_['error_public_key'] = 'Public Key Required!';
$_['error_privat_key'] = 'Privat Key Required!';
$_['error_public_test_key'] = 'Public Test Key Required!';
$_['error_privat_test_key'] = 'Privat Test Key Required!';
$_['error_refresh'] = 'Update failed!';
