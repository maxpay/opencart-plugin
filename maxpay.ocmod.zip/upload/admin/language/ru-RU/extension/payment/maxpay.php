<?php
/**
 * 2020 Maxpay
 * @copyright 2020 Maxpay
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

$_['heading_title']          = 'Способы оплаты Maxpay';

$_['tab_account']            = 'Основные настройки';
$_['tab_payment']            = 'Дополнительные настройки';
$_['tab_order_status']       = 'Статус заказа';
$_['tab_additions']          = 'Дополнение проекта';

$_['text_extension']         = 'Интеграция';
$_['text_success']           = 'Hастройки Maxpay сохранены!';
$_['text_select']            = 'Выберите из списка...';
$_['text_enabled']           = 'Включить';
$_['text_disabled']          = 'Выключить';
$_['text_yes']               = 'Включить';
$_['text_no']                = 'Выключить';
$_['text_on']                = 'Включить';
$_['text_off']               = 'Выключить';
$_['text_edit']              = 'Настройки Maxpay';
$_['text_maxpay']	         = '<img src="view/image/payment/maxpay.png" alt="Maxpay" title="Maxpay" style="height:27px;" />';

$_['label_public_key'] = 'Public Key:';
$_['label_privat_key'] = 'Privat Key:';
$_['label_public_test_key'] = 'Public Test Key:';
$_['label_privat_test_key'] = 'Privat Test Key:';
$_['label_status']           = 'Активировать:';
$_['label_test']             = 'Тестировать:';
$_['label_sort_order']       = 'Порядок сортировки:';
$_['label_total']            = 'Cумма:';
$_['label_title']            = 'Название:';
$_['label_description']      = 'Описание:';
$_['label_paymentlist']      = 'Список платежей:';
$_['label_multi_select']     = 'Определенные страны:';
$_['label_grid_view']        = 'Вид сетки:';
$_['label_geo_zone']         = 'GEO:';
$_['label_new_order_status'] = 'Oжидает подтверждения платежа:';
$_['label_refunded_status']  = 'Возврат:';
$_['label_canceled_status']  = 'Ожидание оплаты:';
$_['label_order_status']     = 'Заказы, подтвержденные Maxpay:';

$_['entry_public_key'] = 'Public key';
$_['entry_privat_key'] = 'Privat Key';
$_['entry_public_test_key'] = 'Public test key';
$_['entry_privat_test_key'] = 'Privat test Key';
$_['entry_total']            = 'Мин. сумма заказа';
$_['entry_title']            = 'Оплатить через систему Maxpay';
$_['entry_description']      = 'Оплата подтверждена системе Maxpay';
$_['entry_sort_order']       = 'Порядок сортировки способа оплаты';
$_['entry_multi_select']     = 'Определенные страны';
$_['entry_owner_code']       = 'Код используется для подтверждения права собственности на веб-сайт';

$_['help_callback']          = '';
$_['help_total']             = 'Мин.сумма заказа, от который отображает  способ оплаты.';
$_['help_multi_select']      = 'Выберите страны, способы оплаты которых будут отображаться (если ничего не выбрано, значит все).';

$_['error_public_key'] = 'Public Key Required!';
$_['error_privat_key'] = 'Privat Key Required!';
$_['error_public_test_key'] = 'Public Test Key Required!';
$_['error_privat_test_key'] = 'Privat Test Key Required!';
$_['error_permission']       = 'Warning: You do not have permission to modify payment Maxpay!';
$_['error_refresh']          = 'Update failed!';
