<?php
/**
 * 2020 Maxpay
 * @copyright 2020 Maxpay
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

/**
 * Class ControllerExtensionPaymentmaxpay
 */
class ControllerExtensionPaymentMaxpay extends Controller
{
    /**
     * Default currency
     */
    const MAXPAY_CURRENCY = 'EUR';

    /**
     * Default language code
     */
    const MAXPAY_DEFAULT_LANG = 'en';

    /**
     * Empty value
     */
    const MAXPAY_EMPTY_VALUE = '';

    /**
     * Default method
     */
    const REQUEST_METHOD_TYPE = 'POST';

    /**
     * Default project id
     */
    const MAXPAY_DEFAULT_PROJECT_ID = 1;

    /**
     * maxpay payment module name
     */
    const MAXPAY_PAYMENT = 'payment_maxpay';

    /**
     * Success text
     */
    const MAXPAY_SUCCESS = 'text_success';

    /**
     * maxpay extension function
     */
    const MAXPAY_EXTENSION_PAYMENT = 'extension/payment/maxpay';

    /**
     * Marketplace extension location
     */
    const MAXPAY_MARKETPLACE_EXTENSIONS = 'marketplace/extension';

    /**
     * Dashboard
     */
    const MAXPAY_COMMON_DASHBOARD = 'common/dashboard';

    /**
     * Prefix used with an error code
     */
    const MAXPAY_ERROR_PREFIX = 'error_';

    /**
     * Callback url
     */
    const MAXPAY_CALLBACK_URL = 'index.php?route=extension/payment/maxpay/callback';

    /**
     * Token param
     */
    const MAXPAY_TOKEN_PARAM = 'user_token=';

    /**
     * Token value
     */
    const MAXPAY_TYPE_PAYMENT = '&type=payment';

    /**
     * maxpay header hook controller
     */
    const MAXPAY_HEADER_CONTROLER = 'extension/payment/maxpay/maxpay_header';

    /**
     * maxpay footer hook controller
     */
    const MAXPAY_FOOTER_CONTROLER = 'extension/payment/maxpay/maxpay_footer';

    /**
     * maxpay order update hook event
     */
    const MAXPAY_EVENT_ORDER_UPDATE = 'catalog/model/checkout/order/addOrderHistory/after';

    /**
     * maxpay order update event name
     */
    const MAXPAY_EVENT_ORDER_UPDATE_NAME = 'maxpay_order_update';

    /**
     * maxpay order update hook controller
     */
    const MAXPAY_EVENT_ORDER_UPDATE_CONTROLER = 'extension/payment/maxpay/update_order';


    /**
     * @var array
     */
    private $error = array();

    /**
     * @var array
     */
    private $errorFieldName = array(
        'warning',
        'public_key',
        'privat_key',
        'public_test_key',
        'privat_test_key'
    );

    /**
     * @var array
     */
    private $breadcrumbFields = array(
        'text_home'      => 'common/dashboard',
        'text_extension' => 'marketplace/extension',
        'heading_title'  => 'extension/payment/maxpay'
    );

    /**
     * @var array
     */
    private $maxpayFieldsName = array(
        'payment_maxpay_status',
        'payment_maxpay_public_key',
        'payment_maxpay_public_test_key',
        'payment_maxpay_privat_key',
        'payment_maxpay_privat_test_key',
        'payment_maxpay_test',
        'payment_maxpay_total',
        'payment_maxpay_title',
        'payment_maxpay_description',
        'payment_maxpay_new_order_status_id',
        'payment_maxpay_paid_status_id',
        'payment_maxpay_pending_status_id',
        'payment_maxpay_refunded_status_id',
        'payment_maxpay_canceled_status_id',
    );

    public function index()
    {
        $this->load->language('extension/payment/maxpay');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if ($this->request->server['REQUEST_METHOD'] == $this::REQUEST_METHOD_TYPE
            && $this->validate()) {
            $this->model_setting_setting->editSetting(
                $this::MAXPAY_PAYMENT,
                $this->request->post
            );

            $this->session->data['success'] = $this->generateData(
                $this::MAXPAY_SUCCESS,
                $this::MAXPAY_EMPTY_VALUE
            );
        }

        foreach ($this->getErrorFieldName() as $fieldName) {
            $dataName = $this::MAXPAY_ERROR_PREFIX . $fieldName;
            $data[$dataName] = $this->errorValue($fieldName);
        }

        foreach ($this->getBreadcrumbFields() as $key => $value) {
            $data['breadcrumbs'][] = $this->generateData($key, $value);
        }

        $data['action'] = $this->generateData(
            $this::MAXPAY_EMPTY_VALUE,
            $this::MAXPAY_EXTENSION_PAYMENT
        );
        $data['cancel'] = $this->generateData(
            $this::MAXPAY_EMPTY_VALUE,
            $this::MAXPAY_MARKETPLACE_EXTENSIONS
        );
        $data['callback'] = HTTP_CATALOG . $this::MAXPAY_CALLBACK_URL;

        foreach ($this->getMaxpayFieldsName() as $fieldName) {
            $data[$fieldName] = $this->generateConfigField($fieldName);
        }


        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this::MAXPAY_EXTENSION_PAYMENT, $data));
    }

    /**
     * @return bool
     */
    protected function validate()
    {
        if (!$this->user->hasPermission('modify', $this::MAXPAY_EXTENSION_PAYMENT)) {
            $this->error['warning'] = $this->language->get('error_warning');
        }

        if (!$this->request->post['payment_maxpay_public_key']) {
            $this->error['public_key'] = $this->language->get('error_public_key');
        }

        if (!$this->request->post['payment_maxpay_privat_key']) {
            $this->error['privat_key'] = $this->language->get('error_privat_key');
        }

        return !$this->error;
    }

    /**
     * @param string $fieldName
     *
     * @return string
     */
    private function errorValue($fieldName)
    {
        if (isset($this->error[$fieldName])) {
            $data = $this->error[$fieldName];
        } else {
            $data = $this::MAXPAY_EMPTY_VALUE;
        }

        return $data;
    }

    /**
     * @param string $text
     * @param string $path
     *
     * @return array
     */
    private function generateData($text, $path)
    {
        if ($path == $this::MAXPAY_MARKETPLACE_EXTENSIONS) {
            $tokenParam = $this::MAXPAY_EMPTY_VALUE;
        } else {
            $tokenParam = $this::MAXPAY_TYPE_PAYMENT;
        }
        $token = $this::MAXPAY_TOKEN_PARAM . $this->session->data['user_token'] . $tokenParam;

        if (empty($text)) {
            $data = $this->url->link($path, $token, true);
        } elseif (empty($path)) {
            $data = $this->language->get($text);
        } else {
            $data = array(
                'text' => $this->language->get($text),
                'href' => $this->url->link($path, $token, true)
            );
        }

        return $data;
    }

    /**
     * @param string $fieldName
     *
     * @return mixed
     */
    private function generateConfigField($fieldName)
    {
        if (isset($this->request->post[$fieldName])) {
            $data = $this->request->post[$fieldName];
        } else {
            $data = $this->config->get($fieldName);
        }

        return $data;
    }

    /**
     * @return array
     */
    private function getErrorFieldName()
    {
        return $this->errorFieldName;
    }

    /**
     * @return array
     */
    private function getMaxpayFieldsName()
    {
        return $this->maxpayFieldsName;
    }

    /**
     * @return array
     */
    public function getBreadcrumbFields()
    {
        return $this->breadcrumbFields;
    }

    public function install() {
        $this->load->model('setting/event');

        $this->model_setting_event->addEvent(
            $this::MAXPAY_EVENT_ORDER_UPDATE_NAME,
            $this::MAXPAY_EVENT_ORDER_UPDATE,
            $this::MAXPAY_EVENT_ORDER_UPDATE_CONTROLER)
        ;
    }

    public function uninstall() {
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode($this::MAXPAY_EVENT_ORDER_UPDATE_NAME);
    }
}
